from django.http import HttpResponse
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseRedirect
from .forms import ApiKeyForm, ContactForm, ContactGroupForm, SendGroupSMSForm, SendSingleSMSForm, SenderIdForm, send2ContactsForm
from .models import ApiKey, Contact, ContactGroup, SenderId, SentSMS

from django.core.paginator import Paginator

import requests
from django.shortcuts import redirect

# Create your views here.


@login_required
def dashboard(request):
    outbox = SentSMS.objects.all().count()
    contacts = Contact.objects.all().count()
    contacts_groups = ContactGroup.objects.all().count()
    senderids = SenderId.objects.all().count()
    return render(request, "bulksms/dashboard.html", {'outbox': outbox,
                                                      'contacts': contacts, 'contact_groups': contacts_groups, 'sender_ids': senderids})


@login_required
def sendSingleSMS(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = SendSingleSMSForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            # print(SenderId.objects.all())
            # SenderId.objects.create(
            #     senderid=form.cleaned_data['senderid'], owner=request.user)
            # print(form.cleaned_data)
            senderid = SenderId.objects.get(pk=form.cleaned_data['senderid'])
            phone_number = form.cleaned_data['phone_numbers'].strip()
            phones = phone_number.splitlines()
            # loop through phone number and invoke sendmessage function
            for phone in phones:

                params = SentSMS.objects.create(
                    owner=request.user, text_message=form.cleaned_data[
                        'message'], sender_id=senderid, phone_number=phone)

                sendTextMessage(params.phone_number,
                                params.text_message, params.sender_id.senderid)

        # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/outbox/')
    else:

        form = SendSingleSMSForm()

        # if a GET (or any other method) we'll create a blank form
        senderids = SenderId.objects.all()

        return render(request, "bulksms/sendsinglesms.html", {'form': form, 'senderids': senderids})


@login_required
def send2contacts(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = send2ContactsForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            # print(SenderId.objects.all())
            # SenderId.objects.create(
            #     senderid=form.cleaned_data['senderid'], owner=request.user)
            # print(form.cleaned_data)
            senderid = SenderId.objects.get(pk=form.cleaned_data['senderid'])
            # phone_number = form.cleaned_data['phone_numbers'].strip()
            # phones = phone_number.splitlines()
            # print('contacts')
            phones = form.cleaned_data['contacts']
            # return 0
            # loop through phone number and invoke sendmessage function
            for phone in phones:

                params = SentSMS.objects.create(
                    owner=request.user, text_message=form.cleaned_data[
                        'message'], sender_id=senderid, phone_number=phone)

                sendTextMessage(params.phone_number,
                                params.text_message, params.sender_id.senderid)

        # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/outbox/')
    else:

        form = send2ContactsForm()

        # if a GET (or any other method) we'll create a blank form

        return render(request, "bulksms/send2contacts.html", {'form': form})
    render(request, "bulksms/send2contacts", {})


@login_required
def sendTextMessage(phone, text, senderid):
    # Send message function
    # print("Send message here")
    # print(messageid)

    # print('params')
    # senderid = params.sender_id.senderid
    # textmsg = params.text_message
    # phone = params.phone_number
    apikeys = ApiKey.objects.order_by('id').last()
    apikey = apikeys.apikey
    # apikeyformatted=

    # print(params.sender_id.senderid)
    endpoint = "https://bulksms.roycetechnologies.co.ke/api/sendmessage"
    data = {"ip": "1.1.2.3", 'sender_id': senderid, 'text_message': text,
            'phone_number': phone}

    headers = {
        "Authorization": "Bearer "+apikey}
    res = requests.post(endpoint, data=data, headers=headers)
    print(res)


@login_required
def outbox(request):

    sent_texts = SentSMS.objects.all().order_by('-id')
    paginator = Paginator(sent_texts, 50)  # Show 25 contacts per page.
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    return render(request, "bulksms/outbox.html", {'sent_texts': page_obj})
    # return render(request, "bulksms/outbox.html", {'sent_texts': sent_texts})


@login_required
def editContacts(request, id):

    # print(id)

    Contact.objects.filter(id=id).delete()

    return redirect('/bulksms/contacts/')

    # return render(request, "bulksms/outbox.html", {'sent_texts': sent_texts})


@login_required
def sendGroupSMS(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = SendGroupSMSForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            # print(SenderId.objects.all())
            # SenderId.objects.create(
            #     senderid=form.cleaned_data['senderid'], owner=request.user)
            # print(form.cleaned_data)
            senderid = SenderId.objects.get(pk=form.cleaned_data['senderid'])
            # phone_number = form.cleaned_data['phone_numbers'].strip()
            # phones = phone_number.splitlines()
            # print('contacts')
            selected_group = ContactGroup.objects.get(
                pk=form.cleaned_data['group'])

            phones = Contact.objects.filter(group=selected_group.id)
            # return 0
            # loop through phone number and invoke sendmessage function

            print(phones)
            # return
            for phone in phones:
                # print(phone)

                params = SentSMS.objects.create(
                    owner=request.user, text_message=form.cleaned_data[
                        'message'], sender_id=senderid, phone_number=phone.phone_number)

                sendTextMessage(params.phone_number,
                                params.text_message, params.sender_id.senderid)

                # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/outbox/')
    else:

        form = SendGroupSMSForm()

        # if a GET (or any other method) we'll create a blank form

        return render(request, "bulksms/sendgroupsms.html", {'form': form})


@login_required
def smsTemplate(request):
    return render(request, "bulksms/smstemplates.html", {})


@login_required
def contacts(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = ContactForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            # print(SenderId.objects.all())
            group = ContactGroup.objects.get(pk=form.cleaned_data['group'])
            Contact.objects.create(
                group=group, description=form.cleaned_data[
                    'description'], name=form.cleaned_data['name'], phone_number=form.cleaned_data['phone_number'],
                phone_number2=form.cleaned_data['phone_number2'],
                owner=request.user)
            print(form.cleaned_data)
            print(SenderId.objects.all())
            # apikeys = ApiKey.objects.all()

        # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/contacts/')
    else:

        form = ContactForm()

        # if a GET (or any other method) we'll create a blank form
        contacts = Contact.objects.all()

        return render(request, "bulksms/contacts.html", {'form': form, 'contacts': contacts})


@login_required
def contactGroups(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = ContactGroupForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            # print(SenderId.objects.all())
            ContactGroup.objects.create(
                group_name=form.cleaned_data['group'], description=form.cleaned_data['description'], owner=request.user)
            print(form.cleaned_data)
            print(SenderId.objects.all())
            # apikeys = ApiKey.objects.all()

        # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/contactgroups/')
    else:

        form = ContactGroupForm()

        # if a GET (or any other method) we'll create a blank form
        groups = ContactGroup.objects.all()

        return render(request, "bulksms/contactgroups.html", {'form': form, 'groups': groups})


@login_required
def senderId(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = SenderIdForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            print(SenderId.objects.all())
            SenderId.objects.create(
                senderid=form.cleaned_data['senderid'], owner=request.user)
            print(form.cleaned_data)
            print(SenderId.objects.all())
            # apikeys = ApiKey.objects.all()

        # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/senderid/')
    else:

        form = SenderIdForm()

        # if a GET (or any other method) we'll create a blank form
        senderids = SenderId.objects.all()

        return render(request, "bulksms/senderId.html", {'form': form, 'senderids': senderids})


@login_required
def apiKeys(request):
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        form = ApiKeyForm(request.POST)
        # check whether it's valid:
        if form.is_valid():
            # process the data in form.cleaned_data as required
            # ...
            # redirect to a new URL:
            # print(ApiKey.objects.all())
            ApiKey.objects.create(
                apikey=form.cleaned_data['apikey'], owner=request.user)
            # print(form.cleaned_data)
            # print(ApiKey.objects.all())
            # apikeys = ApiKey.objects.all()

            # return render(request, "bulksms/apikeys.html", {'form': form, 'apikey': apikeys})
        return HttpResponseRedirect('/bulksms/apikeys/')
    else:

        form = ApiKeyForm()

        # if a GET (or any other method) we'll create a blank form
        apikeys = ApiKey.objects.all()

        return render(request, "bulksms/apikeys.html", {'form': form, 'apikeys': apikeys})
