from django import forms

from .models import Contact, ContactGroup, SenderId


class ApiKeyForm(forms.Form):
    # apikey = forms.CharField(label="Api Key", max_length=255)
    apikey = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'API Key'
        }
    ))


class SenderIdForm(forms.Form):
    # apikey = forms.CharField(label="Api Key", max_length=255)
    senderid = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Sender ID'
        }
    ))


class ContactGroupForm(forms.Form):
    group = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Group Name'
        }
    ))
    description = forms.CharField(required=False, widget=forms.Textarea(
        attrs={
            'class': 'form-control',
            'placeholder': 'Description (Optional)',
            'rows': 4,
        }
    ))


class ContactForm(forms.Form):

    choices = ContactGroup.objects.values_list("id", "group_name")

    group = forms.ChoiceField(widget=forms.Select(
        attrs={
            'class': 'form-control',
            'placeholder': 'Groups',

        }
    ), choices=choices)
    name = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Contact Name'
        }
    ))
    phone_number = forms.CharField(widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Phone Number'
        }
    ))
    phone_number2 = forms.CharField(required=False, widget=forms.TextInput(
        attrs={
            'class': 'form-control',
            'placeholder': 'Alternative number (Optional)'
        }
    ))
    description = forms.CharField(required=False, widget=forms.Textarea(
        attrs={
            'class': 'form-control',
            'placeholder': 'Description (Optional)',
            'rows': 4,
        }
    ))


class send2ContactsForm(forms.Form):
    choices = Contact.objects.values_list("phone_number", "phone_number")

    contacts = forms.MultipleChoiceField(
        required=False,
        widget=forms.CheckboxSelectMultiple,
        choices=choices,
    )

    senderids = SenderId.objects.values_list("id", "senderid")

    senderid = forms.ChoiceField(widget=forms.Select(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',

        }
    ), choices=senderids)
    message = forms.CharField(widget=forms.Textarea(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',
            'rows': 4,
        }
    ))


class SendGroupSMSForm(forms.Form):
    choices = SenderId.objects.values_list("id", "senderid")

    senderid = forms.ChoiceField(widget=forms.Select(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',

        }
    ), choices=choices)

    message = forms.CharField(widget=forms.Textarea(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',
            'rows': 4,
        }
    ))

    groups = ContactGroup.objects.values_list("id", "group_name")

    group = forms.ChoiceField(initial=('', 'Select...'), widget=forms.Select(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',

        }
    ), choices=groups)


class SendSingleSMSForm(forms.Form):
    # apikey = forms.CharField(label="Api Key", max_length=255)
    choices = SenderId.objects.values_list("id", "senderid")

    senderid = forms.ChoiceField(widget=forms.Select(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',

        }
    ), choices=choices)
    message = forms.CharField(widget=forms.Textarea(
        attrs={
            'class': 'form-control',
            'placeholder': 'Text message',
            'rows': 4,
        }
    ))
    phone_numbers = forms.CharField(widget=forms.Textarea(
        attrs={
            'class': 'form-control',
            'placeholder': '0722549778 \n0713727937\n0712 345 678',
            'rows': 8,
        }
    ))
