from django.apps import AppConfig


class RoycebulksmsConfig(AppConfig):
    name = 'roycebulksms'
