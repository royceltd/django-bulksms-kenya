from django.db import models
from django.db.models.deletion import CASCADE
from django.utils import timezone
# Create your models here.
from django.contrib.auth.models import User


class ApiKey(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    apikey = models.CharField(max_length=200)
    created_date = models.DateTimeField(default=timezone.now)


class SenderId(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    senderid = models.CharField(max_length=200)
    created_date = models.DateTimeField(default=timezone.now)


class ContactGroup(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    group_name = models.CharField(max_length=200)
    description = models.CharField(max_length=1000, blank=True, null=True)
    created_date = models.DateTimeField(default=timezone.now)


class Contact(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    phone_number = models.CharField(max_length=200)
    phone_number2 = models.CharField(max_length=200, blank=True, null=True)
    description = models.TextField(null=True)
    group = models.ForeignKey(ContactGroup, on_delete=models.CASCADE)
    created_date = models.DateTimeField(default=timezone.now)


class SentSMS(models.Model):
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    text_message = models.CharField(max_length=1000)
    sender_id = models.ForeignKey(SenderId, on_delete=CASCADE)
    phone_number = models.CharField(max_length=200)
    status = models.CharField(max_length=10, default='Draft')
    sent_at = models.DateTimeField(default=timezone.now)
    message_id = models.CharField(max_length=200,  null=True)
    response_code = models.CharField(max_length=200, blank=True, null=True)
    network_id = models.CharField(max_length=200, blank=True, null=True)
    delivery_status = models.CharField(max_length=200, blank=True, null=True)
    delivery_description = models.CharField(
        max_length=200, blank=True, null=True)
    delivery_tat = models.CharField(max_length=200, blank=True, null=True)
    delivery_networkid = models.CharField(
        max_length=200, blank=True, null=True)
    delivery_time = models.CharField(
        max_length=200, blank=True, null=True)
    delivery_code = models.CharField(
        max_length=200, blank=True, null=True)
    delivery_network_id = models.CharField(
        max_length=200, blank=True, null=True)
    delivery_response_description = models.CharField(
        max_length=200, blank=True, null=True)
