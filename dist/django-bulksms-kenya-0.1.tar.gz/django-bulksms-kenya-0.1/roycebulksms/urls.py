from django.urls import path
from roycebulksms import views
urlpatterns = [
    path('', views.outbox, name="outbox"),
    # path('send/', views.sendBulkSMS, name="sendsms"),
    # path('mydashboard/', views.dashboard, name="dashboard"),
    path('sendsinglesms/', views.sendSingleSMS, name="sendsinglesms"),
    path('outbox/', views.outbox, name="outbox"),
    path('sendgroupsms/', views.sendGroupSMS, name="groupsms"),
    path('smstemplate/', views.smsTemplate, name="smstemplate"),
    path('contacts/', views.contacts, name="contacts"),
    path('editcontacts/<int:id>/', views.editContacts, name="editcontacts"),
    path('sent2contacts/', views.send2contacts, name="sent2contacts"),
    path('contactgroups/', views.contactGroups, name="contactgroups"),
    path('senderid/', views.senderId, name="senderid"),
    path('apikeys/', views.apiKeys, name="apikeys"),

]
